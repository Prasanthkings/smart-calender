function Calendar() {
  const SLOT_ICON = {
    morning: "🌅",
    afternoon: "🌤️",
    night: "🌙"
  };

  const initialEvents = [
    { title: "Daily Standup", date: "2025-11-06", slot: "morning" },
    { title: "Client Meeting", date: "2025-11-15", slot: "afternoon" },
    { title: "Project Review", date: "2025-11-08", slot: "night" }
  ];

  const [events, setEvents] = React.useState(initialEvents);
  const [current, setCurrent] = React.useState(new Date());
  const [show, setShow] = React.useState(false);

  const [newEvent, setNewEvent] = React.useState({
    title: "",
    date: "",
    slot: "morning"
  });

  const year = current.getFullYear();
  const month = current.getMonth();
  const firstDay = new Date(year, month, 1);
  const start = firstDay.getDay();
  const last = new Date(year, month + 1, 0).getDate();

  const today = new Date().toISOString().split("T")[0];

  let cells = [];

  for (let i = 0; i < start; i++) {
    cells.push(<div className="day-box empty" key={"e"+i}></div>);
  }

  for (let d = 1; d <= last; d++) {
    const full = `${year}-${String(month+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
    const dayEvents = events.filter(ev => ev.date === full);

    cells.push(
      <div className={`day-box ${full===today?"today":""}`} key={d}>
        <div className="day-number">{d}</div>

        <div className="event-list">
          {dayEvents.map((ev,i)=>(
            <div className={`event-chip ${ev.slot}`} key={i}>
              <div className="event-icon">{SLOT_ICON[ev.slot]}</div>
              {ev.title}
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="calendar-container">

      {/* Header */}
      <div className="calendar-header">
        <div>
          <h1>{current.toLocaleString("default",{month:"long"})} {year}</h1>
          <p>Manage your schedule with ease</p>
        </div>

        <div className="header-buttons">
          <button className="nav-btn" onClick={()=>setCurrent(new Date(year,month-1,1))}>‹</button>
          <button className="nav-btn" onClick={()=>setCurrent(new Date(year,month+1,1))}>›</button>
          <button className="add-event-btn" onClick={()=>setShow(true)}>＋ Add Event</button>
        </div>
      </div>

      {/* Weekdays */}
      <div className="weekdays">
        <div>Sun</div><div>Mon</div><div>Tue</div>
        <div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
      </div>

      {/* Grid */}
      <div className="calendar-grid">{cells}</div>

      {/* Modal */}
      {show && (
        <div className="modal-overlay">
          <div className="modal">
            <h2>Add Event</h2>

            <input
              placeholder="Title"
              onChange={(e)=>setNewEvent({...newEvent,title:e.target.value})}
            />

            <input
              type="date"
              onChange={(e)=>setNewEvent({...newEvent,date:e.target.value})}
            />

            <select onChange={(e)=>setNewEvent({...newEvent,slot:e.target.value})}>
              <option value="morning">Morning 🌅</option>
              <option value="afternoon">Afternoon 🌤️</option>
              <option value="night">Night 🌙</option>
            </select>

            <button className="submit-btn"
              onClick={()=>{
                setEvents([...events,newEvent]);
                setShow(false);
              }}>Add Event</button>

            <button className="close-btn" onClick={()=>setShow(false)}>Close</button>
          </div>
        </div>
      )}

    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<Calendar />);
